import numpy as np
from typing import Dict, Any

MAX_TIME_COMPLEXITY = 160


class ComplexityCalculator:
    """
    Calculates a weighted complexity score and an error margin 
    based on the number of metrics provided.
    """
    
    def __init__(self, weights: Dict[str, float] = None):
        # Default weights for the calculation
        self.weights = weights or {
            "uncertainty_level": 0.4,
            "technical_complexity": 0.3,
            "manual_effort": 0.2,
            "hours": 0.1,
        }

    def calculate_score(self, inputs: Dict[str, Any]) -> Dict[str, float]:
        provided_metrics = {k: v for k, v in inputs.items() if v is not None}
        num_metrics = len(provided_metrics)
        
        if num_metrics == 0:
            return {"score": 0.0, "margin": 100.0}

        # Normalizing hours (assuming 40h as a baseline for max complexity weight)
        norm_hours = min(provided_metrics.get("hours", 0) / 160 * 10, 10)
        
        values = []
        current_weights = []
        
        for key, val in provided_metrics.items():
            val_to_use = norm_hours if key == "hours" else val
            values.append(val_to_use)
            current_weights.append(self.weights.get(key, 0.1))

        # Weighted Average
        weighted_score = np.average(values, weights=current_weights)
        
        # Error Margin: Higher when fewer metrics are used
        # Formula: 1 - (n_metrics / total_available_metrics)
        margin = (1 - (num_metrics / len(self.weights))) * 50  # Max 50% error
        
        return {
            "score": round(weighted_score, 2),
            "margin": round(margin, 2)
        }
    