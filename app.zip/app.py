import streamlit as st
import numpy as np

from src.config import METRICS_CONFIG

st.set_page_config(page_title="Complexity Engine v2", layout="centered")

st.title("⚖️ Entity-user Synthetic Engineering Index Calculator (EuSEI)")

# 1. Seleção de Métricas (Centralizada)
available_labels = {v["display_name"]: k for k, v in METRICS_CONFIG.items()}
selected_labels = st.multiselect(
    "Selecione as métricas para o cálculo:",
    options=list(available_labels.keys()),
    default=list(available_labels.keys())[:2]
)

# 2. Renderização Dinâmica de Inputs
inputs = {}
st.subheader("Parâmetros da Task")

for label in selected_labels:
    key = available_labels[label]
    conf = METRICS_CONFIG[key]
    
    if conf["type"] == "number":
        inputs[key] = st.number_input(label, min_value=conf["min"], max_value=conf["max"], value=0.0)
    else:
        inputs[key] = st.slider(label, conf["min"], conf["max"], 5)

# 3. Cálculo com Pesos Dinâmicos
def calculate_metrics(user_inputs):
    if not user_inputs:
        return 0, 0
    
    values = []
    weights = []
    
    for key, val in user_inputs.items():
        # Normalização simples para horas (base 40h)
        norm_val = min(val / 4 * 1, 10) if key == "hours" else val
        values.append(norm_val)
        weights.append(METRICS_CONFIG[key]["weight"])
    
    score = np.average(values, weights=weights)
    # Margem de erro baseada na representatividade do peso total usado
    total_weight_used = sum(weights)
    total_possible_weight = sum(m["weight"] for m in METRICS_CONFIG.values())
    margin = (1 - (total_weight_used / total_possible_weight)) * 50
    
    return round(score, 2), round(margin, 1)

score, margin = calculate_metrics(inputs)

# 4. Exibição de Resultados
st.divider()

col1, col2 = st.columns(2)
col1.metric("EuSEI (o) Índice", f"{score}/10")
col2.metric("Margem de Incerteza", f"± {margin}%")

# Novo Bloco de Resposta Consolidada (Pedido pelo usuário)
st.info("### 📝 Resumo da Estimativa")
lower_bound = round(score * (1 - margin/100), 2)
upper_bound = round(score * (1 + margin/100), 2)

st.markdown(f"""
O esforço calculado para esta tarefa, considerando as métricas selecionadas, é de:
**{score} (±{margin}%)**, ou **{score} +- {score * (margin / 100)}**.

> Isso significa que o índice real de complexidade do projeto está no intervalo  **[{lower_bound}, {upper_bound}]**.
""")
